require('dotenv').config();
const express   = require('express');
const cors      = require('cors');
const helmet    = require('helmet');
const morgan    = require('morgan');
const http      = require('http');
const { Server } = require('socket.io');

const app    = express();
const server = http.createServer(app);
const io     = new Server(server, { cors: { origin: '*' } });

// ── Middleware ────────────────────────────────────────────────────────────────
app.use(helmet());
app.use(cors());
app.use(morgan('dev'));
app.use(express.json());

// ── Routes ────────────────────────────────────────────────────────────────────
app.use('/api/auth',          require('./routes/auth'));
app.use('/api/transactions',  require('./routes/transactions'));
app.use('/api/sar',           require('./routes/sar'));
app.use('/api/analytics',     require('./routes/analytics'));
app.use('/api/watchlist',     require('./routes/watchlist'));
app.use('/api/blockchain',    require('./routes/blockchain'));
app.use('/api/whistleblower', require('./routes/whistleblower'));

app.get('/api/health', (req, res) => res.json({ status: 'ok', ts: new Date(), version: '1.0.0' }));

// ── Socket.IO — live transaction feed ────────────────────────────────────────
io.on('connection', (socket) => {
  console.log('Client connected:', socket.id);
  const interval = setInterval(() => {
    socket.emit('transaction', {
      id:      'TXN-' + Math.floor(Math.random() * 9999),
      amount:  Math.floor(Math.random() * 200000),
      risk:    Math.floor(Math.random() * 100),
      type:    ['Wire','ACH','Cash','SWIFT','Crypto'][Math.floor(Math.random() * 5)],
      account: 'ACC-' + Math.floor(Math.random() * 9999),
      ts:      new Date().toISOString(),
    });
  }, 3000 + Math.random() * 2000);
  socket.on('disconnect', () => clearInterval(interval));
});

// ── MongoDB (optional — app works without it using in-memory data) ────────────
const MONGO_URI = process.env.MONGO_URI;
if (MONGO_URI && MONGO_URI !== 'mongodb://localhost:27017/sar_db') {
  try {
    const mongoose = require('mongoose');
    mongoose.connect(MONGO_URI)
      .then(() => console.log('✅ MongoDB connected'))
      .catch(err => console.warn('⚠  MongoDB not connected (running without DB):', err.message));
  } catch {
    console.warn('⚠  mongoose not available, running without DB');
  }
} else {
  console.log('ℹ  Running with in-memory data (no MongoDB required)');
}

// ── Start server ──────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log('');
  console.log('🚀 SAR Backend running on http://localhost:' + PORT);
  console.log('📡 API health: http://localhost:' + PORT + '/api/health');
  console.log('');
});
