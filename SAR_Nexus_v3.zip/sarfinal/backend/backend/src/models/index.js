const mongoose = require('mongoose');
const bcrypt   = require('bcryptjs');

// ── User ────────────────────────────────────────────────────────────────────
const UserSchema = new mongoose.Schema({
  name:      { type: String, required: true },
  email:     { type: String, required: true, unique: true, lowercase: true },
  password:  { type: String, required: true },
  role:      { type: String, enum: ['analyst','officer','legal','admin'], default: 'analyst' },
  active:    { type: Boolean, default: true },
}, { timestamps: true });

UserSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 12);
  next();
});
UserSchema.methods.comparePassword = function (plain) {
  return bcrypt.compare(plain, this.password);
};

// ── Transaction ──────────────────────────────────────────────────────────────
const TransactionSchema = new mongoose.Schema({
  txnId:       { type: String, unique: true, required: true },
  accountId:   { type: String, required: true },
  amount:      { type: Number, required: true },
  currency:    { type: String, default: 'USD' },
  type:        { type: String, enum: ['Wire','ACH','Cash','SWIFT','Crypto','Internal'] },
  counterparty:{ type: String },
  jurisdiction:{ type: String },
  riskScore:   { type: Number, min: 0, max: 100 },
  status:      { type: String, enum: ['pending','flagged','cleared','filed'], default: 'pending' },
  mlSignals:   { type: mongoose.Schema.Types.Mixed },  // SHAP values
  sarId:       { type: mongoose.Schema.Types.ObjectId, ref: 'SAR' },
}, { timestamps: true });

// ── SAR Report ───────────────────────────────────────────────────────────────
const SARSchema = new mongoose.Schema({
  sarId:        { type: String, unique: true, required: true },
  transactions: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Transaction' }],
  accountId:    { type: String, required: true },
  totalAmount:  { type: Number },
  riskScore:    { type: Number },
  type:         { type: String },
  narrative:    { type: String },              // AI-generated
  status:       { type: String, enum: ['draft','pending_review','approved','filed','rejected'], default: 'draft' },
  jurisdiction: { type: String, default: 'FinCEN' },
  analystId:    { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  officerId:    { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  blockchainHash:  { type: String },
  blockchainBlock: { type: Number },
  ipfsCid:      { type: String },
  filedAt:      { type: Date },
  approvedAt:   { type: Date },
  rejectionReason: { type: String },
}, { timestamps: true });

// ── Watchlist Entry ──────────────────────────────────────────────────────────
const WatchlistSchema = new mongoose.Schema({
  accountId:    { type: String, required: true, unique: true },
  accountName:  { type: String },
  riskScore:    { type: Number },
  riskTrend:    { type: String, enum: ['rising','stable','falling'] },
  predictedSAR: { type: Number },   // days until predicted SAR
  watchedSince: { type: Date, default: Date.now },
  reason:       { type: String },
  active:       { type: Boolean, default: true },
}, { timestamps: true });

// ── Blockchain Record ────────────────────────────────────────────────────────
const BlockchainRecordSchema = new mongoose.Schema({
  sarId:       { type: String, required: true },
  txHash:      { type: String, required: true },
  blockNumber: { type: Number },
  network:     { type: String, default: 'Ethereum Sepolia' },
  ipfsCid:     { type: String },
  gasUsed:     { type: String },
  filedBy:     { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  timestamp:   { type: Date, default: Date.now },
}, { timestamps: true });

// ── Whistleblower Tip ────────────────────────────────────────────────────────
const WhistleblowerSchema = new mongoose.Schema({
  refId:       { type: String, required: true, unique: true },
  category:    { type: String },
  encryptedContent: { type: String },   // AES-256 encrypted
  contentHash: { type: String },        // SHA-256
  blockchainHash: { type: String },
  status:      { type: String, enum: ['received','under_review','resolved'], default: 'received' },
}, { timestamps: true });

module.exports = {
  User:           mongoose.model('User', UserSchema),
  Transaction:    mongoose.model('Transaction', TransactionSchema),
  SAR:            mongoose.model('SAR', SARSchema),
  Watchlist:      mongoose.model('Watchlist', WatchlistSchema),
  BlockchainRecord: mongoose.model('BlockchainRecord', BlockchainRecordSchema),
  Whistleblower:  mongoose.model('Whistleblower', WhistleblowerSchema),
};
