const express = require('express');
const router  = express.Router();

router.get('/summary', (req, res) => {
  res.json({ totalTxns: 1247, flagged: 47, sarsFiled: 12, sarsPending: 3, avgResolutionMins: 8.2 });
});

router.get('/monthly', (req, res) => {
  res.json([
    {m:'Aug',filed:8,detected:34},{m:'Sep',filed:11,detected:41},
    {m:'Oct',filed:9,detected:38},{m:'Nov',filed:14,detected:52},
    {m:'Dec',filed:12,detected:47},{m:'Jan',filed:17,detected:63},
  ]);
});

router.get('/accuracy', (req, res) => {
  res.json([
    {day:'Mon',accuracy:91},{day:'Tue',accuracy:93},{day:'Wed',accuracy:89},
    {day:'Thu',accuracy:95},{day:'Fri',accuracy:92},{day:'Sat',accuracy:96},{day:'Sun',accuracy:94},
  ]);
});

module.exports = router;
