const express = require('express');
const crypto  = require('crypto');
const router  = express.Router();

const RECORDS = [
  { sarId:'SAR-2024-0088', txHash:'0x7c2e...8d3b', blockNumber:19278432, network:'Ethereum Sepolia', gasUsed:'0.002 ETH', timestamp:'2024-01-14T09:15:00Z' },
  { sarId:'SAR-2024-0087', txHash:'0x9d4b...1f7a', blockNumber:19277890, network:'Ethereum Sepolia', gasUsed:'0.002 ETH', timestamp:'2024-01-14T07:01:00Z' },
  { sarId:'SAR-2024-0086', txHash:'0xf1a8...3c9d', blockNumber:19272011, network:'Ethereum Sepolia', gasUsed:'0.002 ETH', timestamp:'2024-01-13T22:12:00Z' },
];

router.get('/records', (req, res) => res.json(RECORDS));

router.post('/file/:sarId', (req, res) => {
  const txHash = '0x' + crypto.randomBytes(32).toString('hex');
  const record = { sarId: req.params.sarId, txHash, blockNumber: 19000000 + Math.floor(Math.random()*500000), network:'Ethereum Sepolia', gasUsed:'0.002 ETH', timestamp: new Date().toISOString() };
  RECORDS.unshift(record);
  res.json({ success: true, txHash, blockNumber: record.blockNumber });
});

router.get('/verify/:hash', (req, res) => {
  const record = RECORDS.find(r => r.txHash.includes(req.params.hash));
  res.json({ verified: !!record, record: record || null });
});

module.exports = router;
