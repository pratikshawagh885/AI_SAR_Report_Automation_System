const express = require('express');
const router  = express.Router();
const crypto  = require('crypto');

const SARS = [
  { sarId:'SAR-2024-0089', accountId:'ACC-4421', amount:148200, riskScore:94, type:'Structuring + Wire', status:'pending_review', jurisdiction:'FinCEN', analyst:'Sarah K.', createdAt:'2024-01-15T14:32:00Z', narrative:'On January 15, 2024, account ACC-4421 conducted a wire transfer of $148,200 to an offshore account in a FATF high-risk jurisdiction. This amount is approximately 8.3 times the account\'s 90-day average transaction value of $17,800.\n\nIn the 24 hours preceding this transaction, the account executed 14 additional transfers totaling $62,400 — consistent with structuring behavior designed to evade the $10,000 reporting threshold.\n\nPursuant to 31 U.S.C. § 5318(g) and FinCEN regulatory requirements, this SAR is being filed.', signals:{'Amount vs average':42,'High-risk jurisdiction':31,'Transaction velocity':28,'Structuring pattern':22} },
  { sarId:'SAR-2024-0088', accountId:'ACC-7832', amount:9800, riskScore:78, type:'Smurfing', status:'filed', jurisdiction:'FinCEN', analyst:'Mike R.', blockchainHash:'0x7c2e8d3b', createdAt:'2024-01-14T09:11:00Z', narrative:'Smurfing activity detected across multiple accounts.', signals:{'Structuring pattern':38,'Velocity spike':24} },
  { sarId:'SAR-2024-0087', accountId:'ACC-2291', amount:52000, riskScore:65, type:"Int'l Wire", status:'approved', jurisdiction:'FCA', analyst:'Sarah K.', createdAt:'2024-01-14T06:55:00Z', narrative:'International wire transfer to high-risk jurisdiction.', signals:{'High-risk jurisdiction':31,'New counterparty':18} },
];

router.get('/', (req, res) => {
  const { status } = req.query;
  const data = status ? SARS.filter(s => s.status === status) : SARS;
  res.json(data);
});

router.get('/:id', (req, res) => {
  const sar = SARS.find(s => s.sarId === req.params.id);
  sar ? res.json(sar) : res.status(404).json({ error: 'SAR not found' });
});

router.post('/', (req, res) => {
  const sarId = 'SAR-' + new Date().getFullYear() + '-' + String(Math.floor(Math.random()*9999)).padStart(4,'0');
  const sar = { sarId, ...req.body, status:'draft', createdAt: new Date().toISOString() };
  SARS.unshift(sar);
  res.status(201).json(sar);
});

router.patch('/:id/approve', (req, res) => {
  const sar = SARS.find(s => s.sarId === req.params.id);
  if (!sar) return res.status(404).json({ error: 'Not found' });
  sar.status = 'approved';
  sar.approvedAt = new Date().toISOString();
  res.json(sar);
});

router.patch('/:id/reject', (req, res) => {
  const sar = SARS.find(s => s.sarId === req.params.id);
  if (!sar) return res.status(404).json({ error: 'Not found' });
  sar.status = 'rejected';
  sar.rejectionReason = req.body.reason;
  res.json(sar);
});

module.exports = router;
