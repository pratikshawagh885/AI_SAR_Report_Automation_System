const express = require('express');
const crypto  = require('crypto');
const router  = express.Router();

const TIPS = [];

router.post('/submit', (req, res) => {
  const { category, content } = req.body;
  const refId         = 'WB-' + crypto.randomBytes(4).toString('hex').toUpperCase();
  const contentHash   = crypto.createHash('sha256').update(content || '').digest('hex');
  const blockchainHash = '0x' + crypto.randomBytes(32).toString('hex');
  TIPS.push({ refId, category, contentHash, blockchainHash, status:'received', createdAt: new Date().toISOString() });
  res.status(201).json({ refId, blockchainHash, message: 'Submission received and encrypted' });
});

router.get('/status/:refId', (req, res) => {
  const tip = TIPS.find(t => t.refId === req.params.refId);
  tip ? res.json(tip) : res.status(404).json({ error: 'Not found' });
});

module.exports = router;
