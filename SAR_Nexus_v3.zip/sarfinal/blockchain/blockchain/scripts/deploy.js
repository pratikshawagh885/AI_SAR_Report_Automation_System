// scripts/deploy.js
const { ethers } = require('hardhat');

async function main() {
  const [deployer] = await ethers.getSigners();
  console.log('Deploying with account:', deployer.address);
  console.log('Balance:', ethers.formatEther(await deployer.provider.getBalance(deployer.address)), 'ETH');

  const SARRegistry = await ethers.getContractFactory('SARRegistry');
  const registry    = await SARRegistry.deploy();
  await registry.waitForDeployment();

  const address = await registry.getAddress();
  console.log('✅ SARRegistry deployed to:', address);
  console.log('Add to .env: CONTRACT_ADDRESS=' + address);
}

main().catch(e => { console.error(e); process.exit(1); });
