import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import Layout from './components/Layout';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import { Transactions, TransactionDetail } from './pages/Transactions';
import { AddTransaction, SARReports, SARDetail } from './pages/SARPages';
import { Accounts, Watchlist, Blockchain, AuditLog, Whistleblower } from './pages/OtherPages';

function Guard({ children }) {
  const { user } = useAuth();
  return user ? children : <Navigate to="/login" replace/>;
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login/>}/>
          <Route path="/" element={<Guard><Layout/></Guard>}>
            <Route index               element={<Dashboard/>}/>
            <Route path="transactions"  element={<Transactions/>}/>
            <Route path="transactions/:id" element={<TransactionDetail/>}/>
            <Route path="accounts"      element={<Accounts/>}/>
            <Route path="reports"       element={<SARReports/>}/>
            <Route path="reports/:id"   element={<SARDetail/>}/>
            <Route path="add-txn"       element={<AddTransaction/>}/>
            <Route path="watchlist"     element={<Watchlist/>}/>
            <Route path="blockchain"    element={<Blockchain/>}/>
            <Route path="audit"         element={<AuditLog/>}/>
            <Route path="whistleblower" element={<Whistleblower/>}/>
          </Route>
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}
