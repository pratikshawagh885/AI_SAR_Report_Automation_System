import React, { useState } from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const ROLE_ROUTES = {
  analyst: [
    { to:'/',            e:true,  icon:'📊', label:'Dashboard'       },
    { to:'/transactions',         icon:'💳', label:'Transactions'    },
    { to:'/add-txn',              icon:'➕', label:'Add Transaction'  },
    { to:'/accounts',             icon:'👤', label:'Account Profiles' },
    { to:'/reports',              icon:'📋', label:'SAR Reports'      },
    { to:'/watchlist',            icon:'👁', label:'Watchlist'        },
    { to:'/whistleblower',        icon:'🔐', label:'Whistleblower'   },
  ],
  officer: [
    { to:'/',            e:true,  icon:'📊', label:'Dashboard'       },
    { to:'/transactions',         icon:'💳', label:'Transactions'    },
    { to:'/add-txn',              icon:'➕', label:'Add Transaction'  },
    { to:'/accounts',             icon:'👤', label:'Account Profiles' },
    { to:'/reports',              icon:'📋', label:'SAR Reports'      },
    { to:'/watchlist',            icon:'👁', label:'Watchlist'        },
    { to:'/blockchain',           icon:'⛓', label:'Blockchain'       },
    { to:'/audit',                icon:'📜', label:'Audit Log'        },
    { to:'/whistleblower',        icon:'🔐', label:'Whistleblower'   },
  ],
  legal: [
    { to:'/',            e:true,  icon:'📊', label:'Dashboard'       },
    { to:'/reports',              icon:'📋', label:'SAR Reports'      },
    { to:'/blockchain',           icon:'⛓', label:'Blockchain'       },
    { to:'/audit',                icon:'📜', label:'Audit Log'        },
    { to:'/whistleblower',        icon:'🔐', label:'Whistleblower'   },
  ],
  admin: [
    { to:'/',            e:true,  icon:'📊', label:'Dashboard'       },
    { to:'/transactions',         icon:'💳', label:'Transactions'    },
    { to:'/add-txn',              icon:'➕', label:'Add Transaction'  },
    { to:'/accounts',             icon:'👤', label:'Account Profiles' },
    { to:'/reports',              icon:'📋', label:'SAR Reports'      },
    { to:'/watchlist',            icon:'👁', label:'Watchlist'        },
    { to:'/blockchain',           icon:'⛓', label:'Blockchain'       },
    { to:'/audit',                icon:'📜', label:'Audit Log'        },
    { to:'/whistleblower',        icon:'🔐', label:'Whistleblower'   },
  ],
};

export default function Layout() {
  const { user, logout } = useAuth();
  const nav = useNavigate();
  const [col, setCol] = useState(false);
  const routes = ROLE_ROUTES[user?.role] || [];

  return (
    <div style={{display:'flex',height:'100vh',overflow:'hidden',fontFamily:"'DM Sans',sans-serif",background:'#0f1117'}}>
      {/* Sidebar */}
      <aside style={{width:col?58:215,background:'#1a1d27',borderRight:'1px solid #2d3147',display:'flex',flexDirection:'column',transition:'width .22s',flexShrink:0,overflow:'hidden',position:'relative'}}>
        {/* Logo */}
        <div style={{padding:'14px 10px',borderBottom:'1px solid #2d3147',display:'flex',alignItems:'center',gap:10,minHeight:58}}>
          <div style={{width:32,height:32,background:'#4f6ef7',borderRadius:9,display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0,boxShadow:'0 0 14px rgba(79,110,247,.3)',fontSize:16}}>⚡</div>
          {!col && <div><div style={{fontFamily:"'Sora',sans-serif",fontSize:13,fontWeight:600,color:'#fff'}}>SAR Nexus</div><div style={{fontSize:10,color:'#475569'}}>AI Compliance</div></div>}
        </div>

        {/* Navigation */}
        <nav style={{flex:1,padding:'8px 6px',overflowY:'auto',overflowX:'hidden'}}>
          {routes.map(r => (
            <NavLink key={r.to} to={r.to} end={r.e} style={({isActive})=>({
              display:'flex',alignItems:'center',gap:10,padding:'8px 9px',borderRadius:9,
              marginBottom:2,textDecoration:'none',fontSize:13,transition:'all .15s',overflow:'hidden',
              background:isActive?'rgba(79,110,247,.18)':'transparent',
              color:isActive?'#818cf8':'#64748b',
              border:isActive?'1px solid rgba(79,110,247,.3)':'1px solid transparent',
            })}>
              <span style={{fontSize:15,flexShrink:0}}>{r.icon}</span>
              {!col && <span style={{whiteSpace:'nowrap'}}>{r.label}</span>}
            </NavLink>
          ))}
        </nav>

        {/* User profile */}
        <div style={{borderTop:'1px solid #2d3147',padding:'10px 8px'}}>
          {!col && <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:8,padding:'4px 2px'}}>
            <div style={{width:30,height:30,borderRadius:8,background:user?.color+'33',display:'flex',alignItems:'center',justifyContent:'center',fontSize:11,fontWeight:700,color:user?.color,flexShrink:0}}>{user?.avatar}</div>
            <div style={{minWidth:0,flex:1}}>
              <div style={{fontSize:12,fontWeight:600,color:'#e2e8f0',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{user?.name}</div>
              <div style={{fontSize:10,color:user?.color,fontWeight:700,textTransform:'uppercase'}}>{user?.role}</div>
            </div>
          </div>}
          <button onClick={()=>{logout();nav('/login');}}
            style={{display:'flex',alignItems:'center',gap:8,width:'100%',background:'transparent',border:'none',color:'#ef4444',cursor:'pointer',padding:'6px 8px',borderRadius:8,fontSize:12,fontWeight:500}}>
            <span style={{fontSize:14}}>🚪</span>{!col && 'Sign out'}
          </button>
        </div>

        {/* Collapse toggle */}
        <button onClick={()=>setCol(!col)} style={{position:'absolute',top:66,right:-13,width:25,height:25,background:'#2d3147',border:'1px solid #3d4261',borderRadius:'50%',cursor:'pointer',color:'#94a3b8',fontSize:13,display:'flex',alignItems:'center',justifyContent:'center',zIndex:10}}>
          {col?'›':'‹'}
        </button>
      </aside>

      {/* Main area */}
      <div style={{flex:1,display:'flex',flexDirection:'column',overflow:'hidden'}}>
        {/* Top bar */}
        <header style={{background:'#1a1d27',borderBottom:'1px solid #2d3147',padding:'9px 20px',display:'flex',justifyContent:'space-between',alignItems:'center',flexShrink:0}}>
          <div style={{display:'flex',alignItems:'center',gap:8}}>
            <span style={{width:7,height:7,borderRadius:'50%',background:'#22c55e',display:'inline-block',animation:'p 2s infinite'}}/>
            <style>{`@keyframes p{0%,100%{opacity:1}50%{opacity:.4}}`}</style>
            <span style={{fontSize:11,color:'#475569'}}>System live · Real-time monitoring</span>
          </div>
          <div style={{fontSize:11,color:'#475569'}}>{new Date().toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric',year:'numeric'})}</div>
        </header>
        <main style={{flex:1,overflowY:'auto',padding:'1.4rem'}}>
          <Outlet/>
        </main>
      </div>
    </div>
  );
}
