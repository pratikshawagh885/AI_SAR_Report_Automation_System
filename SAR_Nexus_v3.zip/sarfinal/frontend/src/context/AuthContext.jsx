import React, { createContext, useContext, useState } from 'react';

const Ctx = createContext(null);
export const useAuth = () => useContext(Ctx);

const USERS = [
  { id:'1', name:'Sarah K.',  email:'analyst@sar.io',  pass:'demo123', role:'analyst',  avatar:'SK', color:'#4f6ef7' },
  { id:'2', name:'Mike R.',   email:'officer@sar.io',  pass:'demo123', role:'officer',  avatar:'MR', color:'#f59e0b' },
  { id:'3', name:'James T.',  email:'legal@sar.io',    pass:'demo123', role:'legal',    avatar:'JT', color:'#8b5cf6' },
  { id:'4', name:'Admin',     email:'admin@sar.io',    pass:'demo123', role:'admin',    avatar:'AD', color:'#ef4444' },
];

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => { try { return JSON.parse(localStorage.getItem('sar_u')); } catch { return null; } });

  const login = (email, pass) => {
    const u = USERS.find(x => x.email===email && x.pass===pass);
    if (!u) throw new Error('Invalid credentials');
    const safe = { id:u.id, name:u.name, email:u.email, role:u.role, avatar:u.avatar, color:u.color };
    localStorage.setItem('sar_u', JSON.stringify(safe));
    setUser(safe); return safe;
  };

  const logout = () => { localStorage.removeItem('sar_u'); setUser(null); };

  // What each role CAN do
  const CAPS = {
    analyst: ['view','addTxn','createSAR','whistleblower'],
    officer: ['view','addTxn','createSAR','approveSAR','rejectSAR','fileSAR','sendWarning','sendEmail','whistleblower'],
    legal:   ['view','auditLog','whistleblower'],
    admin:   ['view','addTxn','createSAR','approveSAR','rejectSAR','fileSAR','sendWarning','sendEmail','auditLog','whistleblower','manageUsers'],
  };
  const can = (action) => (CAPS[user?.role] || []).includes(action);

  return <Ctx.Provider value={{ user, login, logout, can }}>{children}</Ctx.Provider>;
}
