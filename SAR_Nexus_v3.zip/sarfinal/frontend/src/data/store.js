// src/data/store.js
// Single source of truth. All pages read and write here.
// Uses React state pattern via callbacks for reactivity.

const CALLBACKS = [];
function notify() { CALLBACKS.forEach(fn => fn()); }
export function subscribe(fn) { CALLBACKS.push(fn); return () => { const i = CALLBACKS.indexOf(fn); if (i>-1) CALLBACKS.splice(i,1); }; }

// ── Master accounts ─────────────────────────────────────────────────────────
export const ACCOUNTS = [
  { id:'ACC-4421', name:'Phantom Corp LLC',     type:'Business', country:'Cayman Islands', avgMonthly:18000,  riskLevel:'high',   email:'finance@phantom.ky',        phone:'+1-345-555-0182' },
  { id:'ACC-8821', name:'John Doe',             type:'Personal', country:'USA',            avgMonthly:4200,   riskLevel:'high',   email:'john.doe@gmail.com',        phone:'+1-212-555-0143' },
  { id:'ACC-5571', name:'Neon Digital Ltd',     type:'Business', country:'Panama',         avgMonthly:44000,  riskLevel:'high',   email:'accounts@neondig.pa',       phone:'+507-555-0174' },
  { id:'ACC-1109', name:'Carlos Rivera',        type:'Personal', country:'Mexico',         avgMonthly:3100,   riskLevel:'high',   email:'c.rivera@email.mx',         phone:'+52-55-555-0198' },
  { id:'ACC-2291', name:'Global Trade Inc',     type:'Business', country:'UK',             avgMonthly:95000,  riskLevel:'medium', email:'compliance@globaltrade.uk', phone:'+44-20-555-0161' },
  { id:'ACC-7832', name:'Swift Remit Ltd',      type:'Business', country:'India',          avgMonthly:31000,  riskLevel:'medium', email:'ops@swiftremit.in',         phone:'+91-22-555-0177' },
  { id:'ACC-3312', name:'Maria Santos',         type:'Personal', country:'Brazil',         avgMonthly:2800,   riskLevel:'low',    email:'maria.s@email.br',          phone:'+55-11-555-0165' },
  { id:'ACC-6634', name:'Tech Ventures LLC',    type:'Business', country:'USA',            avgMonthly:220000, riskLevel:'low',    email:'cfo@techventures.com',      phone:'+1-415-555-0139' },
];

// ── Master transactions ──────────────────────────────────────────────────────
let TRANSACTIONS = [
  { id:'TXN-9821', accountId:'ACC-4421', amount:148200, type:'Wire Transfer',  country:'Cayman Islands', counterparty:'Offshore Holdings Ltd', velocity:14, offHours:true,  riskScore:94, status:'flagged',  time:'2024-01-15T14:32:00Z', signals:{'Amount 8× avg':42,'High-risk jurisdiction':31,'Velocity spike':28,'Structuring':22,'Off-hours':8}, notes:'14 transactions in 24h — classic layering' },
  { id:'TXN-9820', accountId:'ACC-8821', amount:9800,   type:'Cash Deposit',   country:'USA',            counterparty:'Branch ATM-082',        velocity:9,  offHours:false, riskScore:88, status:'flagged',  time:'2024-01-15T11:20:00Z', signals:{'Sub-threshold amount':38,'Multiple deposits':28,'Structuring pattern':22}, notes:'3rd sub-$10k deposit this week — smurfing' },
  { id:'TXN-9819', accountId:'ACC-5571', amount:73000,  type:'SWIFT',          country:'Panama',         counterparty:'Shell Corp BVI',        velocity:7,  offHours:true,  riskScore:91, status:'flagged',  time:'2024-01-15T02:14:00Z', signals:{'FATF jurisdiction':31,'Shell company':28,'Off-hours':12,'Amount spike':20}, notes:'FATF high-risk jurisdiction, 2 AM transfer' },
  { id:'TXN-9818', accountId:'ACC-1109', amount:31500,  type:'Wire Transfer',  country:'Mexico',         counterparty:'Unknown Entity',        velocity:11, offHours:false, riskScore:85, status:'flagged',  time:'2024-01-14T19:45:00Z', signals:{'Unknown counterparty':32,'High velocity':28,'Amount ratio':25}, notes:'Unverified counterparty, 10× account avg' },
  { id:'TXN-9817', accountId:'ACC-2291', amount:52000,  type:"Int'l Transfer", country:'UK',             counterparty:'EU Partner GmbH',       velocity:3,  offHours:false, riskScore:65, status:'review',   time:'2024-01-14T15:30:00Z', signals:{'Amount above avg':28,"Int'l jurisdiction":18,'New counterparty':12}, notes:'Elevated but counterparty is registered' },
  { id:'TXN-9816', accountId:'ACC-7832', amount:18500,  type:'ACH',            country:'India',          counterparty:'Domestic Bank Ltd',     velocity:4,  offHours:false, riskScore:55, status:'review',   time:'2024-01-14T10:00:00Z', signals:{'Above 30d avg':22,'Velocity slight':12}, notes:'Slightly above average, flagged for review' },
  { id:'TXN-9815', accountId:'ACC-3312', amount:2400,   type:'ACH',            country:'Brazil',         counterparty:'Local Merchant SA',     velocity:2,  offHours:false, riskScore:18, status:'cleared',  time:'2024-01-13T09:15:00Z', signals:{}, notes:'Normal consumer spending pattern' },
  { id:'TXN-9814', accountId:'ACC-6634', amount:185000, type:'Wire Transfer',  country:'USA',            counterparty:'AWS Services Inc',      velocity:1,  offHours:false, riskScore:11, status:'cleared',  time:'2024-01-13T08:00:00Z', signals:{}, notes:'Known recurring vendor payment' },
  { id:'TXN-9813', accountId:'ACC-4421', amount:9500,   type:'Cash Deposit',   country:'Cayman Islands', counterparty:'ATM-Cayman-001',        velocity:14, offHours:true,  riskScore:89, status:'flagged',  time:'2024-01-13T03:22:00Z', signals:{'Part of structuring':38,'Off-hours':12,'High-risk jur.':31}, notes:'Part of layering sequence with TXN-9821' },
  { id:'TXN-9812', accountId:'ACC-8821', amount:9700,   type:'Cash Deposit',   country:'USA',            counterparty:'ATM-Branch-019',        velocity:9,  offHours:false, riskScore:82, status:'flagged',  time:'2024-01-12T14:55:00Z', signals:{'Sub-threshold':38,'Velocity':22,'Pattern':18}, notes:'2nd in smurfing sequence' },
];

// ── SAR Reports ──────────────────────────────────────────────────────────────
let SARS = [
  {
    id:'SAR-2024-0089', accountId:'ACC-4421', txnIds:['TXN-9821','TXN-9813'],
    amount:157700, riskScore:94, type:'Structuring + Wire Transfer',
    status:'pending_review', jurisdiction:'FinCEN', createdBy:'Sarah K.', createdAt:'2024-01-15T15:00:00Z',
    narrative:`On January 15, 2024, account ACC-4421 (Phantom Corp LLC, Cayman Islands) conducted a wire transfer of $148,200 to Offshore Holdings Ltd — a FATF high-risk jurisdiction entity. This amount is 8.3× the account's 90-day daily average of $17,800.\n\nIn the preceding 24 hours, the same account executed 14 additional cash deposits totaling $62,400, all structured below the $10,000 CTR threshold — consistent with layering behavior.\n\nThe AI graph model identified this account as a high-centrality node in a network of 7 accounts with coordinated activity. Risk score: 94/100.\n\nPursuant to 31 U.S.C. § 5318(g), this SAR is submitted for regulatory review.`,
    signals:{'Amount 8× avg':42,'High-risk jurisdiction':31,'Velocity spike':28,'Structuring pattern':22,'Off-hours':8},
    approvedBy:null, approvedAt:null, rejectedBy:null, rejectionReason:null,
    filedBy:null, filedAt:null, blockchainHash:null,
    warnings:[], emails:[],
  },
  {
    id:'SAR-2024-0088', accountId:'ACC-8821', txnIds:['TXN-9820','TXN-9812'],
    amount:19500, riskScore:85, type:'Smurfing / Structuring',
    status:'filed', jurisdiction:'FinCEN', createdBy:'Mike R.', createdAt:'2024-01-14T09:00:00Z',
    narrative:`Account ACC-8821 (John Doe, USA) made three consecutive cash deposits: $9,800, $9,700, $9,600 — all just below the $10,000 CTR threshold over 6 days.\n\nThis pattern constitutes "smurfing" — a structuring technique designed to evade mandatory Currency Transaction Reporting. No legitimate business reason was identified.\n\nAI model confidence: 0.91. This SAR has been approved and filed on-chain.`,
    signals:{'Sub-threshold amounts':38,'Multiple deposits':28,'Structuring pattern':22},
    approvedBy:'Mike R.', approvedAt:'2024-01-14T10:00:00Z',
    filedBy:'Mike R.', filedAt:'2024-01-14T10:05:00Z',
    blockchainHash:'0x7c2e8d3b1a9f4e2c5d8f1a3b',
    warnings:['Warning issued 2024-01-14 by Mike R.'],
    emails:['Email sent to john.doe@gmail.com on 2024-01-14'],
  },
  {
    id:'SAR-2024-0087', accountId:'ACC-2291', txnIds:['TXN-9817'],
    amount:52000, riskScore:65, type:"Int'l Wire — Elevated Risk",
    status:'approved', jurisdiction:'FCA', createdBy:'Sarah K.', createdAt:'2024-01-14T07:00:00Z',
    narrative:`Account ACC-2291 (Global Trade Inc, UK) executed an international wire of $52,000 to EU Partner GmbH. While the counterparty is registered, the amount exceeds the 30-day average by 45%.\n\nRisk score 65 reflects elevated but non-conclusive suspicion. Approved for FCA filing as a precautionary measure.`,
    signals:{"Amount above avg":28,"Int'l jurisdiction":18,'New counterparty':12},
    approvedBy:'Mike R.', approvedAt:'2024-01-14T08:00:00Z',
    filedBy:null, filedAt:null, blockchainHash:null,
    warnings:[], emails:[],
  },
];

let BLOCKCHAIN = [
  { sarId:'SAR-2024-0088', txHash:'0x7c2e8d3b1a9f4e2c5d8f1a3b', block:19278432, ts:'2024-01-14T10:05:00Z', gas:'0.002 ETH', network:'Ethereum Sepolia', filedBy:'Mike R.' },
];

let AUDIT_LOG = [
  { action:'System started',     detail:'SAR Nexus v2 initialized',                                                ts:'2024-01-15T08:00:00Z', user:'System' },
  { action:'SAR Filed On-Chain', detail:'SAR-2024-0088 → Block #19278432 by Mike R.',                            ts:'2024-01-14T10:05:00Z', user:'Mike R.' },
  { action:'SAR Approved',       detail:'SAR-2024-0087 approved by Mike R.',                                     ts:'2024-01-14T08:00:00Z', user:'Mike R.' },
  { action:'Warning Issued',     detail:'⚠ ACC-8821 (John Doe) — Compliance review notice by Mike R.',          ts:'2024-01-14T09:30:00Z', user:'Mike R.' },
  { action:'Email Sent',         detail:'📧 To: john.doe@gmail.com | Compliance Notice | By: Mike R.',          ts:'2024-01-14T09:35:00Z', user:'Mike R.' },
];

// ── ML risk engine (deterministic, based on real signals) ────────────────────
const HIGH_RISK_COUNTRIES = new Set(['Cayman Islands','Panama','Belize','BVI','Vanuatu','Seychelles','Marshall Islands']);
export function mlScore(txn, account) {
  const signals = {};
  let score = 0;
  const daily = (account?.avgMonthly || 10000) / 30;
  const ratio = txn.amount / Math.max(daily, 1);

  if (ratio > 2)  { const s = Math.min(42, Math.round((ratio-2)*6)); signals[`Amount ${ratio.toFixed(1)}× daily avg`] = s; score += s; }
  if (txn.velocity > 6) { const s = Math.min(28, txn.velocity * 2); signals[`Velocity: ${txn.velocity} txns/24h`] = s; score += s; }
  if (HIGH_RISK_COUNTRIES.has(txn.country)) { signals['High-risk jurisdiction'] = 31; score += 31; }
  if (txn.amount > 9000 && txn.amount < 10000) { signals['Sub-threshold structuring'] = 22; score += 22; }
  if (txn.offHours) { signals['Off-hours transaction'] = 8; score += 8; }
  if (txn.counterparty && txn.counterparty.toLowerCase().includes('unknown')) { signals['Unknown counterparty'] = 18; score += 18; }

  const finalScore = Math.min(99, Math.max(1, Math.round(score)));
  return { score: finalScore, signals, label: finalScore>=80?'HIGH':finalScore>=55?'MEDIUM':'LOW' };
}

// ── Account history (unique per account using deterministic seed) ────────────
export function accountHistory(accountId) {
  const acc = ACCOUNTS.find(a => a.id === accountId);
  const base = acc?.avgMonthly || 10000;
  const seed = accountId.split('').reduce((a,c)=>a+c.charCodeAt(0),0);
  return ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'].map((month, i) => {
    const pseudo = ((seed * 1103515245 + (i+1)*12345) >>> 0) % 1000;
    const spikeMult = [4,10].includes(i) ? 3.5 : 1;
    return { month, amount: Math.round(base * spikeMult * (0.65 + pseudo/1000*0.7)) };
  });
}

// ── Mutable store API ────────────────────────────────────────────────────────
export const DB = {
  transactions: () => [...TRANSACTIONS],
  sars:         () => [...SARS],
  blockchain:   () => [...BLOCKCHAIN],
  auditLog:     () => [...AUDIT_LOG],
  account:      (id) => ACCOUNTS.find(a=>a.id===id),

  addTransaction(data) {
    const acc = ACCOUNTS.find(a=>a.id===data.accountId);
    const { score, signals, label } = mlScore(data, acc);
    const txn = {
      ...data,
      id: 'TXN-'+(Date.now()%100000),
      riskScore: score,
      signals,
      status: score>=80?'flagged':score>=55?'review':'cleared',
      time: new Date().toISOString(),
      notes: `ML analysis: ${label} risk. ${Object.entries(signals).map(([k])=>k).join(', ') || 'No signals detected'}.`,
    };
    TRANSACTIONS.unshift(txn);
    this._log('Transaction Added', `${txn.id} (${data.accountId}) $${data.amount.toLocaleString()} — Risk: ${score}/100`, 'System');
    notify(); return txn;
  },

  createSAR(txnId, analyst) {
    const txn = TRANSACTIONS.find(t=>t.id===txnId);
    if (!txn) return null;
    const acc = ACCOUNTS.find(a=>a.id===txn.accountId);
    const sarId = 'SAR-'+new Date().getFullYear()+'-'+String(Math.floor(Math.random()*9000+1000));
    const sar = {
      id:sarId, accountId:txn.accountId, txnIds:[txnId],
      amount:txn.amount, riskScore:txn.riskScore, type:txn.type,
      status:'pending_review', jurisdiction:'FinCEN', createdBy:analyst, createdAt:new Date().toISOString(),
      narrative:`On ${new Date().toLocaleDateString('en-US',{year:'numeric',month:'long',day:'numeric'})}, account ${txn.accountId} (${acc?.name}) conducted a ${txn.type} of $${txn.amount.toLocaleString()} to ${txn.counterparty} (${txn.country}).\n\n${txn.notes}\n\nML risk signals detected: ${Object.entries(txn.signals).map(([k,v])=>`${k} (score: +${v})`).join(', ') || 'None'}.\n\nOverall risk score: ${txn.riskScore}/100. This report was auto-generated by the AI system and requires compliance officer review prior to regulatory filing.\n\nPursuant to 31 U.S.C. § 5318(g) and applicable FinCEN SAR requirements.`,
      signals:txn.signals,
      approvedBy:null, approvedAt:null, rejectedBy:null, rejectionReason:null,
      filedBy:null, filedAt:null, blockchainHash:null, warnings:[], emails:[],
    };
    SARS.unshift(sar);
    this._log('SAR Created', `${sarId} from ${txnId} by ${analyst}`, analyst);
    notify(); return sar;
  },

  approveSAR(sarId, officer) {
    SARS = SARS.map(s=>s.id===sarId ? {...s, status:'approved', approvedBy:officer, approvedAt:new Date().toISOString()} : s);
    this._log('SAR Approved', `${sarId} approved by ${officer}`, officer);
    notify();
  },

  rejectSAR(sarId, reason, officer) {
    SARS = SARS.map(s=>s.id===sarId ? {...s, status:'rejected', rejectedBy:officer, rejectionReason:reason, rejectedAt:new Date().toISOString()} : s);
    this._log('SAR Rejected', `${sarId} rejected by ${officer} — reason: "${reason}"`, officer);
    notify();
  },

  fileSAR(sarId, officer) {
    const hash = '0x'+Array.from({length:24},()=>'0123456789abcdef'[Math.floor(Math.random()*16)]).join('');
    const block = 19000000+Math.floor(Math.random()*500000);
    SARS = SARS.map(s=>s.id===sarId ? {...s, status:'filed', blockchainHash:hash, filedBy:officer, filedAt:new Date().toISOString()} : s);
    BLOCKCHAIN.unshift({sarId, txHash:hash, block, ts:new Date().toISOString(), gas:'0.002 ETH', network:'Ethereum Sepolia', filedBy:officer});
    this._log('SAR Filed On-Chain', `${sarId} → Block #${block} | Hash: ${hash.slice(0,14)}... by ${officer}`, officer);
    notify(); return hash;
  },

  sendWarning(accountId, message, officer) {
    const acc = ACCOUNTS.find(a=>a.id===accountId);
    const msg = `⚠ Warning to ${accountId} (${acc?.name}): "${message}" — by ${officer}`;
    SARS = SARS.map(s=>s.accountId===accountId ? {...s, warnings:[...s.warnings, `${new Date().toLocaleDateString()} by ${officer}: ${message}`]} : s);
    this._log('Warning Issued', msg, officer);
    notify(); return true;
  },

  sendEmail(accountId, subject, body, officer) {
    const acc = ACCOUNTS.find(a=>a.id===accountId);
    const msg = `📧 To: ${acc?.email} | Subject: "${subject}" | By: ${officer}`;
    SARS = SARS.map(s=>s.accountId===accountId ? {...s, emails:[...s.emails, `${new Date().toLocaleDateString()} by ${officer}: ${subject}`]} : s);
    this._log('Email Notice Sent', msg, officer);
    notify(); return true;
  },

  _log(action, detail, user) {
    AUDIT_LOG.unshift({ action, detail, user, ts:new Date().toISOString() });
  },
};
