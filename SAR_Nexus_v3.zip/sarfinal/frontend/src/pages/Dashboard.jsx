import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { DB, ACCOUNTS, subscribe } from '../data/store';
import { Stat, Card, RiskBadge, SBadge, Btn } from '../components/UI';

const TT = { contentStyle:{background:'#1a1d27',border:'1px solid #3d4261',borderRadius:9,fontSize:11} };
const TX = { fill:'#475569',fontSize:11 };

const AREA = [
  {t:'00:00',v:82,f:2},{t:'03:00',v:41,f:1},{t:'06:00',v:190,f:4},{t:'09:00',v:580,f:11},
  {t:'12:00',v:940,f:19},{t:'14:00',v:1240,f:23},{t:'16:00',v:870,f:14},{t:'18:00',v:640,f:9},{t:'21:00',v:420,f:6},{t:'Now',v:310,f:4},
];
const PIE = [{n:'Wire Transfer',v:34,c:'#4f6ef7'},{n:'Cash Deposit',v:22,c:'#ef4444'},{n:'Structuring',v:19,c:'#f59e0b'},{n:'ACH/SWIFT',v:15,c:'#8b5cf6'},{n:'Other',v:10,c:'#3d4261'}];

export default function Dashboard() {
  const nav = useNavigate();
  const [, tick] = useState(0);
  const [live, setLive] = useState(1247);

  useEffect(() => {
    const unsub = subscribe(()=>tick(t=>t+1));
    const iv = setInterval(()=>setLive(p=>p+Math.floor(Math.random()*3)),2800);
    return ()=>{ unsub(); clearInterval(iv); };
  }, []);

  const txns = DB.transactions();
  const sars  = DB.sars();
  const flagged = txns.filter(t=>t.status==='flagged');
  const pending = sars.filter(s=>s.status==='pending_review'||s.status==='draft');
  const filed   = sars.filter(s=>s.status==='filed');

  return (
    <div style={{display:'flex',flexDirection:'column',gap:'1.1rem'}}>
      <div>
        <h1 style={{fontFamily:"'Sora',sans-serif",fontSize:20,fontWeight:600,color:'#fff',margin:0}}>Compliance Dashboard</h1>
        <p style={{fontSize:12,color:'#64748b',marginTop:3,marginBottom:0}}>Real-time SAR monitoring and ML threat detection</p>
      </div>

      {/* KPI row */}
      <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:'0.9rem'}}>
        <Stat icon="💳" label="Live Transactions"  value={live.toLocaleString()} sub="↑ 12% vs yesterday" accent="#4f6ef7"/>
        <Stat icon="🚨" label="Flagged Today"       value={String(flagged.length)} sub="Requires review"   accent="#ef4444"/>
        <Stat icon="⏳" label="SARs Pending"        value={String(pending.length)} sub="Awaiting officer"  accent="#f59e0b"/>
        <Stat icon="⛓" label="Filed On-Chain"       value={String(filed.length)}   sub="Blockchain verified" accent="#22c55e"/>
      </div>

      {/* Charts */}
      <div style={{display:'grid',gridTemplateColumns:'2fr 1fr',gap:'0.9rem'}}>
        <Card>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:12}}>
            <span style={{fontSize:13,fontWeight:500,color:'#e2e8f0'}}>Transaction Volume vs Flags (24h)</span>
            <span style={{fontSize:10,background:'rgba(34,197,94,.15)',color:'#6ee7b7',padding:'2px 9px',borderRadius:20,border:'1px solid rgba(34,197,94,.3)'}}>● LIVE</span>
          </div>
          <ResponsiveContainer width="100%" height={175}>
            <AreaChart data={AREA}>
              <defs>
                <linearGradient id="gv" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#4f6ef7" stopOpacity={0.3}/><stop offset="95%" stopColor="#4f6ef7" stopOpacity={0}/></linearGradient>
                <linearGradient id="gf" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#ef4444" stopOpacity={0.3}/><stop offset="95%" stopColor="#ef4444" stopOpacity={0}/></linearGradient>
              </defs>
              <XAxis dataKey="t" tick={TX} axisLine={false} tickLine={false}/>
              <YAxis tick={TX} axisLine={false} tickLine={false}/>
              <Tooltip {...TT}/>
              <Area type="monotone" dataKey="v" stroke="#4f6ef7" fill="url(#gv)" strokeWidth={2} name="Transactions"/>
              <Area type="monotone" dataKey="f" stroke="#ef4444" fill="url(#gf)" strokeWidth={2} name="Flagged"/>
            </AreaChart>
          </ResponsiveContainer>
        </Card>
        <Card>
          <div style={{fontSize:13,fontWeight:500,color:'#e2e8f0',marginBottom:12}}>Suspicious Activity Types</div>
          <ResponsiveContainer width="100%" height={115}>
            <PieChart><Pie data={PIE} cx="50%" cy="50%" innerRadius={30} outerRadius={52} paddingAngle={3} dataKey="v">
              {PIE.map((e,i)=><Cell key={i} fill={e.c}/>)}
            </Pie><Tooltip {...TT}/></PieChart>
          </ResponsiveContainer>
          <div style={{marginTop:8,display:'flex',flexDirection:'column',gap:4}}>
            {PIE.map(d=>(
              <div key={d.n} style={{display:'flex',justifyContent:'space-between',fontSize:11}}>
                <div style={{display:'flex',alignItems:'center',gap:5}}>
                  <span style={{width:7,height:7,borderRadius:'50%',background:d.c,display:'inline-block'}}/>
                  <span style={{color:'#94a3b8'}}>{d.n}</span>
                </div>
                <span style={{color:'#e2e8f0',fontWeight:600}}>{d.v}%</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Recent flagged */}
      <Card>
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:12}}>
          <span style={{fontSize:13,fontWeight:500,color:'#e2e8f0'}}>Recent Flagged Transactions</span>
          <Btn sm ghost onClick={()=>nav('/transactions')}>View all →</Btn>
        </div>
        <table style={{width:'100%',borderCollapse:'collapse',fontSize:12}}>
          <thead><tr style={{borderBottom:'1px solid #2d3147'}}>
            {['ID','Account','Amount','Risk','Type','Status','Action'].map(h=>(
              <th key={h} style={{textAlign:'left',padding:'7px 10px',color:'#475569',fontWeight:500}}>{h}</th>
            ))}
          </tr></thead>
          <tbody>
            {txns.filter(t=>t.status==='flagged').slice(0,5).map(t=>(
              <tr key={t.id} style={{borderBottom:'1px solid #1a1d27',cursor:'pointer'}}
                onMouseEnter={e=>e.currentTarget.style.background='#1e2535'}
                onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
                <td style={{padding:'9px 10px',color:'#818cf8',fontFamily:'monospace'}}>{t.id}</td>
                <td style={{padding:'9px 10px',color:'#94a3b8'}}>{t.accountId}</td>
                <td style={{padding:'9px 10px',color:'#fff',fontWeight:600}}>${t.amount.toLocaleString()}</td>
                <td style={{padding:'9px 10px'}}><RiskBadge score={t.riskScore}/></td>
                <td style={{padding:'9px 10px',color:'#64748b'}}>{t.type}</td>
                <td style={{padding:'9px 10px'}}><SBadge status={t.status}/></td>
                <td style={{padding:'9px 10px'}}>
                  <Btn sm onClick={()=>nav(`/transactions/${t.id}`)}>Analyse →</Btn>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      {/* High-risk accounts summary */}
      <Card>
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:12}}>
          <span style={{fontSize:13,fontWeight:500,color:'#e2e8f0'}}>High-Risk Accounts</span>
          <Btn sm ghost onClick={()=>nav('/accounts')}>View profiles →</Btn>
        </div>
        <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:'0.7rem'}}>
          {ACCOUNTS.filter(a=>a.riskLevel==='high').map(a=>(
            <div key={a.id} onClick={()=>nav('/accounts')} style={{background:'rgba(239,68,68,.08)',border:'1px solid rgba(239,68,68,.2)',borderRadius:10,padding:'0.7rem',cursor:'pointer'}}>
              <div style={{fontSize:12,fontWeight:600,color:'#e2e8f0',marginBottom:3}}>{a.name}</div>
              <div style={{fontSize:10,color:'#64748b'}}>{a.id} · {a.country}</div>
              <SBadge status="high"/>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
