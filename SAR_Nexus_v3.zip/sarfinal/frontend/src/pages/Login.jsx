import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const DEMOS = [
  { email:'analyst@sar.io', role:'analyst', desc:'Flag txns · Create SARs',              color:'#4f6ef7' },
  { email:'officer@sar.io', role:'officer', desc:'Approve · Reject · File on-chain',     color:'#f59e0b' },
  { email:'legal@sar.io',   role:'legal',   desc:'Read-only · Audit log · Reports',      color:'#8b5cf6' },
  { email:'admin@sar.io',   role:'admin',   desc:'Full access · Warn · Email accounts',  color:'#ef4444' },
];

export default function Login() {
  const { login } = useAuth();
  const nav = useNavigate();
  const [email, setEmail] = useState('officer@sar.io');
  const [pass,  setPass]  = useState('demo123');
  const [err,   setErr]   = useState('');
  const [busy,  setBusy]  = useState(false);

  const submit = async e => {
    e.preventDefault(); setErr(''); setBusy(true);
    await new Promise(r=>setTimeout(r,600));
    try { login(email,pass); nav('/'); } catch(ex) { setErr(ex.message); }
    setBusy(false);
  };

  return (
    <div style={{minHeight:'100vh',background:'#0f1117',display:'flex',alignItems:'center',justifyContent:'center',padding:'1rem',fontFamily:"'DM Sans',sans-serif"}}>
      <div style={{width:'100%',maxWidth:380}}>
        <div style={{textAlign:'center',marginBottom:'2rem'}}>
          <div style={{width:58,height:58,background:'#4f6ef7',borderRadius:16,display:'flex',alignItems:'center',justifyContent:'center',margin:'0 auto 1rem',boxShadow:'0 0 28px rgba(79,110,247,.4)',fontSize:26}}>⚡</div>
          <h1 style={{fontFamily:"'Sora',sans-serif",fontSize:24,fontWeight:700,color:'#fff',margin:0}}>SAR Nexus</h1>
          <p style={{fontSize:13,color:'#475569',marginTop:5}}>AI-Powered Compliance Intelligence</p>
        </div>

        <div style={{background:'#1a1d27',border:'1px solid #2d3147',borderRadius:16,padding:'1.5rem',marginBottom:'1rem'}}>
          <form onSubmit={submit}>
            <div style={{marginBottom:'1rem'}}>
              <div style={{fontSize:11,color:'#94a3b8',marginBottom:5}}>Email</div>
              <input value={email} onChange={e=>setEmail(e.target.value)} type="email" required
                style={{width:'100%',background:'#232635',border:'1px solid #3d4261',color:'#e2e8f0',borderRadius:9,padding:'10px 13px',fontSize:13,boxSizing:'border-box',outline:'none'}}/>
            </div>
            <div style={{marginBottom:'1.2rem'}}>
              <div style={{fontSize:11,color:'#94a3b8',marginBottom:5}}>Password</div>
              <input value={pass} onChange={e=>setPass(e.target.value)} type="password" required
                style={{width:'100%',background:'#232635',border:'1px solid #3d4261',color:'#e2e8f0',borderRadius:9,padding:'10px 13px',fontSize:13,boxSizing:'border-box',outline:'none'}}/>
            </div>
            {err && <div style={{color:'#f87171',fontSize:12,textAlign:'center',marginBottom:'1rem'}}>{err}</div>}
            <button type="submit" disabled={busy}
              style={{width:'100%',background:'#4f6ef7',color:'#fff',border:'none',borderRadius:9,padding:12,fontSize:14,fontWeight:700,cursor:'pointer',opacity:busy?0.7:1}}>
              {busy?'Signing in…':'Sign In →'}
            </button>
          </form>
        </div>

        <div style={{background:'#1a1d27',border:'1px solid #2d3147',borderRadius:14,padding:'1rem'}}>
          <div style={{fontSize:11,color:'#475569',marginBottom:'0.6rem',fontWeight:600}}>DEMO ACCOUNTS — password: demo123</div>
          {DEMOS.map(d=>(
            <button key={d.email} onClick={()=>{setEmail(d.email);setPass('demo123');}}
              style={{display:'flex',alignItems:'center',justifyContent:'space-between',width:'100%',background:'transparent',border:'none',padding:'7px 8px',borderRadius:8,cursor:'pointer',marginBottom:2,transition:'background .15s'}}
              onMouseEnter={e=>e.currentTarget.style.background='#232635'}
              onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
              <div style={{textAlign:'left'}}>
                <div style={{fontSize:12,color:'#cbd5e1'}}>{d.email}</div>
                <div style={{fontSize:10,color:'#475569'}}>{d.desc}</div>
              </div>
              <span style={{fontSize:10,background:d.color+'22',color:d.color,border:`1px solid ${d.color}44`,padding:'2px 10px',borderRadius:20,fontWeight:700,flexShrink:0,marginLeft:8}}>{d.role.toUpperCase()}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
