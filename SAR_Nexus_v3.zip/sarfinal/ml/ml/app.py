"""
SAR ML Service — Flask API
Exposes: /predict, /generate-narrative, /train, /explain
"""
from flask import Flask, request, jsonify
from flask_cors import CORS
import numpy as np
import pandas as pd
from datetime import datetime
import logging, os, json

app = Flask(__name__)
CORS(app)
logging.basicConfig(level=logging.INFO)

# ── Lazy model imports (so the app starts even without GPU) ──────────────────
def get_models():
    try:
        from sklearn.ensemble import IsolationForest, RandomForestClassifier
        from sklearn.preprocessing import StandardScaler
        import joblib
        return IsolationForest, RandomForestClassifier, StandardScaler, joblib
    except ImportError:
        return None, None, None, None


# ── Feature Engineering ───────────────────────────────────────────────────────
def extract_features(txn: dict) -> np.ndarray:
    """Convert a transaction dict into a feature vector."""
    HIGH_RISK_JURISDICTIONS = {'CAYMAN','PANAMA','BELIZE','VANUATU','SAMOA','SEYCHELLES'}

    amount        = float(txn.get('amount', 0))
    account_avg   = float(txn.get('accountAvg', 10000))  # 90-day avg
    velocity_24h  = int(txn.get('velocity24h', 1))       # txns in 24h
    counterparty_new = int(txn.get('counterpartyNew', 0))
    jurisdiction  = txn.get('jurisdiction', '').upper()
    high_risk_jur = int(jurisdiction in HIGH_RISK_JURISDICTIONS)
    amount_ratio  = amount / max(account_avg, 1)
    is_round      = int(amount % 1000 == 0 and amount > 0)
    hour          = datetime.now().hour
    is_off_hours  = int(hour < 6 or hour > 22)

    return np.array([[
        amount, account_avg, amount_ratio,
        velocity_24h, counterparty_new, high_risk_jur,
        is_round, is_off_hours,
    ]])


def compute_risk_score(features: np.ndarray, txn: dict) -> tuple:
    """Heuristic risk scoring with SHAP-style signal breakdown."""
    f = features[0]
    amount, avg, ratio, velocity, new_party, high_risk, is_round, off_hours = f

    signals = {}
    score   = 0.0

    # Signal weights
    if ratio > 5:     s = min(42, (ratio - 5) * 4);  signals['Amount vs average']  = round(s); score += s
    if high_risk:     s = 31;                          signals['High-risk jurisdiction'] = s;    score += s
    if velocity > 10: s = min(28, velocity * 2);       signals['Transaction velocity']   = round(s); score += s
    if is_round:      s = 12;                           signals['Round amount pattern']   = s;    score += s
    if new_party:     s = 9;                            signals['New counterparty']       = s;    score += s
    if off_hours:     s = 8;                            signals['Off-hours transaction']  = s;    score += s

    final_score = min(99, max(1, int(score)))
    return final_score, signals


# ── Routes ────────────────────────────────────────────────────────────────────

@app.get('/health')
def health():
    return jsonify({'status': 'ok', 'service': 'SAR ML', 'ts': datetime.utcnow().isoformat()})


@app.post('/predict')
def predict():
    """
    Input:  transaction JSON
    Output: { riskScore, signals, label }
    """
    try:
        txn      = request.json or {}
        features = extract_features(txn)
        risk, signals = compute_risk_score(features, txn)
        label    = 'HIGH' if risk >= 80 else 'MEDIUM' if risk >= 50 else 'LOW'
        return jsonify({ 'riskScore': risk, 'signals': signals, 'label': label, 'confidence': round(min(0.99, risk / 100 + 0.1), 2) })
    except Exception as e:
        app.logger.error(f'Predict error: {e}')
        return jsonify({'error': str(e)}), 500


@app.post('/generate-narrative')
def generate_narrative():
    """
    Generate a SAR narrative. Uses OpenAI if key is set, else template.
    Input:  { accountId, amount, type, riskScore, signals, jurisdiction, ... }
    Output: { narrative }
    """
    try:
        data = request.json or {}

        # Try OpenAI
        openai_key = os.getenv('OPENAI_API_KEY')
        if openai_key and openai_key.startswith('sk-'):
            try:
                import openai
                client = openai.OpenAI(api_key=openai_key)
                prompt = f"""You are a compliance officer filing a Suspicious Activity Report (SAR).
Write a professional, concise SAR narrative based on:
- Account: {data.get('accountId')}
- Transaction Amount: ${data.get('amount', 0):,.2f}
- Transaction Type: {data.get('type')}
- Risk Score: {data.get('riskScore')}/100
- Risk Signals: {json.dumps(data.get('signals', {}))}
- Jurisdiction: {data.get('jurisdiction', 'USA')}
- Date: {datetime.utcnow().strftime('%Y-%m-%d')}

Write 3-4 paragraphs. Include: what was observed, why it is suspicious, regulatory basis for filing."""
                resp = client.chat.completions.create(
                    model='gpt-4o-mini',
                    messages=[{'role':'user','content':prompt}],
                    max_tokens=600
                )
                return jsonify({'narrative': resp.choices[0].message.content, 'source': 'gpt-4o-mini'})
            except Exception as e:
                app.logger.warning(f'OpenAI failed: {e}')

        # Fallback template
        narrative = f"""On {datetime.utcnow().strftime('%B %d, %Y')}, account {data.get('accountId', '[ACCOUNT]')} conducted a {data.get('type', 'financial')} transaction of ${float(data.get('amount', 0)):,.2f}.

The transaction was flagged by the automated monitoring system with a risk score of {data.get('riskScore', 'N/A')}/100. The following anomalies were detected: {', '.join(f'{k} (score: +{v})' for k, v in (data.get('signals') or {}).items())}.

Based on the pattern analysis, this activity may be consistent with {data.get('type', 'suspicious financial activity')} intended to avoid regulatory reporting thresholds. The account's transaction velocity and counterparty risk profile are consistent with known typologies for financial crime.

Pursuant to 31 U.S.C. § 5318(g) and applicable FinCEN guidance, this Suspicious Activity Report is being filed. The reporting institution requests this report remain confidential pursuant to 31 U.S.C. § 5318(g)(2)."""

        return jsonify({'narrative': narrative, 'source': 'template'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.post('/batch-predict')
def batch_predict():
    """Score a batch of transactions."""
    try:
        transactions = request.json or []
        results = []
        for txn in transactions:
            features = extract_features(txn)
            risk, signals = compute_risk_score(features, txn)
            results.append({'txnId': txn.get('txnId'), 'riskScore': risk, 'signals': signals})
        return jsonify(results)
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.get('/watchlist/predict')
def predict_watchlist():
    """Mock predictive watchlist — in prod this queries the GNN."""
    accounts = [
        {'accountId': 'ACC-4421', 'riskScore': 94, 'trend': 'rising',  'predictedSARDays': 7},
        {'accountId': 'ACC-8821', 'riskScore': 88, 'trend': 'rising',  'predictedSARDays': 14},
        {'accountId': 'ACC-2291', 'riskScore': 72, 'trend': 'stable',  'predictedSARDays': 21},
        {'accountId': 'ACC-7832', 'riskScore': 65, 'trend': 'falling', 'predictedSARDays': 30},
    ]
    return jsonify(accounts)


if __name__ == '__main__':
    port = int(os.getenv('ML_PORT', 8000))
    app.logger.info(f'🧠 ML Service starting on port {port}')
    app.run(host='0.0.0.0', port=port, debug=os.getenv('FLASK_DEBUG', 'false').lower() == 'true')
